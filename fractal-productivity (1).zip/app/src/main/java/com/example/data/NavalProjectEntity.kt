package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class LeverageType {
    CODE, MEDIA, CAPITAL, PERMISSIONLESS_LABOR
}

@Entity(tableName = "naval_projects")
data class NavalProjectEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val specificKnowledge: String,
    val leverageType: LeverageType = LeverageType.CODE,
    val productizationIdea: String,
    val monetizationStrategy: String,
    val automationSteps: String,
    val progressPercent: Int = 10,
    val targetImpactOrRevenue: String = "$10k/mo MRR",
    val status: String = "In Development", // e.g. "Planning", "In Development", "Monetized", "Scaled"
    val createdAt: Long = System.currentTimeMillis()
)
