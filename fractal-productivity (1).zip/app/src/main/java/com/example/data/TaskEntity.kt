package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class Priority {
    URGENT, HIGH, MEDIUM, LOW
}

enum class TaskCategory {
    DEEP_WORK, QUICK_WIN, ROUTINE, NAVAL_GOAL
}

enum class Recurrence {
    NONE, DAILY, WEEKLY, WEEKDAYS
}

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val category: TaskCategory = TaskCategory.DEEP_WORK,
    val priority: Priority = Priority.MEDIUM,
    val scheduledDate: String, // Format YYYY-MM-DD
    val startTime: String = "09:00", // HH:mm
    val endTime: String = "10:00", // HH:mm
    val isCompleted: Boolean = false,
    val isDeepWorkBlock: Boolean = false,
    val reminderTime: String? = null, // e.g. "15 mins before"
    val recurrence: Recurrence = Recurrence.NONE,
    val xpReward: Int = 25,
    val navalProjectId: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)
