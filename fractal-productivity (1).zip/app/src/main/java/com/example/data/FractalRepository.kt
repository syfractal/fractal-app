package com.example.data

import kotlinx.coroutines.flow.Flow
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class FractalRepository(private val dao: FractalDao) {

    val allTasks: Flow<List<TaskEntity>> = dao.getAllTasks()
    val allHabits: Flow<List<HabitEntity>> = dao.getAllHabits()
    val allNavalProjects: Flow<List<NavalProjectEntity>> = dao.getAllNavalProjects()
    val userGamification: Flow<UserGamificationEntity?> = dao.getUserGamification()

    fun getTasksForDate(date: String): Flow<List<TaskEntity>> = dao.getTasksForDate(date)

    suspend fun insertTask(task: TaskEntity) = dao.insertTask(task)
    suspend fun updateTask(task: TaskEntity) = dao.updateTask(task)
    suspend fun deleteTask(task: TaskEntity) = dao.deleteTask(task)

    suspend fun insertHabit(habit: HabitEntity) = dao.insertHabit(habit)
    suspend fun updateHabit(habit: HabitEntity) = dao.updateHabit(habit)
    suspend fun deleteHabit(habit: HabitEntity) = dao.deleteHabit(habit)

    suspend fun insertNavalProject(project: NavalProjectEntity) = dao.insertNavalProject(project)
    suspend fun updateNavalProject(project: NavalProjectEntity) = dao.updateNavalProject(project)
    suspend fun deleteNavalProject(project: NavalProjectEntity) = dao.deleteNavalProject(project)

    suspend fun addXpAndProgress(xpAmount: Int, deepWorkMins: Int = 0) {
        val current = dao.getUserGamificationDirect() ?: UserGamificationEntity()
        var newXp = current.currentXp + xpAmount
        var newLevel = current.userLevel
        var reqXp = current.requiredXp
        var completedTasks = current.totalTasksCompleted + 1
        var totalDeepWork = current.totalDeepWorkMinutes + deepWorkMins

        while (newXp >= reqXp) {
            newXp -= reqXp
            newLevel += 1
            reqXp = (reqXp * 1.4).toInt()
        }

        val updated = current.copy(
            userLevel = newLevel,
            currentXp = newXp,
            requiredXp = reqXp,
            totalTasksCompleted = completedTasks,
            totalDeepWorkMinutes = totalDeepWork
        )
        dao.insertOrUpdateGamification(updated)
    }

    suspend fun checkAndSeedInitialData() {
        if (dao.getTaskCount() == 0) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val calendar = Calendar.getInstance()
            val todayStr = sdf.format(calendar.time)

            calendar.add(Calendar.DAY_OF_YEAR, 1)
            val tomorrowStr = sdf.format(calendar.time)

            // Seed initial tasks
            dao.insertTask(
                TaskEntity(
                    title = "Deep Work Block: Architecture & Code Leverage",
                    description = "Focus for 90 mins uninterrupted on core product leverage strategy",
                    category = TaskCategory.DEEP_WORK,
                    priority = Priority.URGENT,
                    scheduledDate = todayStr,
                    startTime = "09:00",
                    endTime = "10:30",
                    isCompleted = false,
                    isDeepWorkBlock = true,
                    reminderTime = "10 mins before",
                    recurrence = Recurrence.WEEKDAYS,
                    xpReward = 50
                )
            )

            dao.insertTask(
                TaskEntity(
                    title = "Naval Principle: Map Productization of Self",
                    description = "Break down specific knowledge into scalable digital media & code assets",
                    category = TaskCategory.NAVAL_GOAL,
                    priority = Priority.HIGH,
                    scheduledDate = todayStr,
                    startTime = "11:00",
                    endTime = "12:00",
                    isCompleted = true,
                    isDeepWorkBlock = true,
                    xpReward = 40
                )
            )

            dao.insertTask(
                TaskEntity(
                    title = "Clear Email & Async Communication",
                    description = "Quick sweep of inbox and daily async project updates",
                    category = TaskCategory.QUICK_WIN,
                    priority = Priority.LOW,
                    scheduledDate = todayStr,
                    startTime = "14:00",
                    endTime = "14:30",
                    isCompleted = false,
                    isDeepWorkBlock = false,
                    recurrence = Recurrence.DAILY,
                    xpReward = 15
                )
            )

            dao.insertTask(
                TaskEntity(
                    title = "Weekly System Audit & Calendar Buffer Alignment",
                    description = "Review time blocks and upcoming high-leverage milestones",
                    category = TaskCategory.ROUTINE,
                    priority = Priority.MEDIUM,
                    scheduledDate = tomorrowStr,
                    startTime = "10:00",
                    endTime = "11:00",
                    isCompleted = false,
                    isDeepWorkBlock = false,
                    recurrence = Recurrence.WEEKLY,
                    xpReward = 30
                )
            )
        }

        if (dao.getHabitCount() == 0) {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val cal = Calendar.getInstance()
            val dates = mutableListOf<String>()
            for (i in 0..4) {
                dates.add(sdf.format(cal.time))
                cal.add(Calendar.DAY_OF_YEAR, -1)
            }
            val historyCsv = dates.joinToString(",")

            dao.insertHabit(
                HabitEntity(
                    title = "Daily 90-Min Deep Work Sprint",
                    description = "Zero phone distractions, single monomaniacal task focus",
                    targetDaysPerWeek = 7,
                    currentStreak = 5,
                    bestStreak = 12,
                    colorHex = "#6366F1",
                    completedDatesCsv = historyCsv
                )
            )

            dao.insertHabit(
                HabitEntity(
                    title = "Read Naval / High-Leverage Philosophy",
                    description = "15 minutes of non-fiction, mental models, or code study",
                    targetDaysPerWeek = 5,
                    currentStreak = 4,
                    bestStreak = 8,
                    colorHex = "#10B981",
                    completedDatesCsv = historyCsv
                )
            )

            dao.insertHabit(
                HabitEntity(
                    title = "Physical Calibration & Sunlight",
                    description = "30 mins movement, outdoor walk or workout before deep work",
                    targetDaysPerWeek = 7,
                    currentStreak = 6,
                    bestStreak = 14,
                    colorHex = "#F59E0B",
                    completedDatesCsv = historyCsv
                )
            )
        }

        if (dao.getNavalProjectCount() == 0) {
            dao.insertNavalProject(
                NavalProjectEntity(
                    title = "Automated SaaS / Micro-Service Platform",
                    specificKnowledge = "Algorithmic backend design, workflow automation, custom UI/UX design",
                    leverageType = LeverageType.CODE,
                    productizationIdea = "Build a zero-maintenance API engine that processes complex workflows automatically",
                    monetizationStrategy = "Subscription model ($29/mo tier for individual creators, $99/mo for power users)",
                    automationSteps = "Deploy on serverless cloud infra, automated Stripe billing, AI triage support",
                    progressPercent = 45,
                    targetImpactOrRevenue = "$15,000 / mo MRR",
                    status = "In Development"
                )
            )

            dao.insertNavalProject(
                NavalProjectEntity(
                    title = "Permissionless Knowledge Media Hub",
                    specificKnowledge = "Deep domain expertise in product design, high-leverage mental models, and tech architecture",
                    leverageType = LeverageType.MEDIA,
                    productizationIdea = "Synthesize timeless guides & software tools into an iconic newsletter and media ecosystem",
                    monetizationStrategy = "Sponsorships, digital product bundles, premium cohort workshops",
                    automationSteps = "Scheduled release pipelines, automated distribution via API webhooks",
                    progressPercent = 25,
                    targetImpactOrRevenue = "100k Readers & $8k/mo",
                    status = "Planning"
                )
            )
        }

        if (dao.getUserGamificationDirect() == null) {
            dao.insertOrUpdateGamification(
                UserGamificationEntity(
                    id = 1,
                    userLevel = 2,
                    currentXp = 125,
                    requiredXp = 250,
                    totalTasksCompleted = 18,
                    totalDeepWorkMinutes = 360,
                    currentStreakDays = 5,
                    unlockedBadgesCsv = "DEEP_WORK_TITAN,STREAK_5_DAYS,NAVAL_PIONEER,FIRST_LEVERAGE",
                    completedChallengeIdsCsv = "CHALLENGE_DEEP_WORK_3"
                )
            )
        }
    }
}
