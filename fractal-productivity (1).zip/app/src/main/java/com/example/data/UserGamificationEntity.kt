package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_gamification")
data class UserGamificationEntity(
    @PrimaryKey val id: Long = 1,
    val userLevel: Int = 1,
    val currentXp: Int = 85,
    val requiredXp: Int = 200,
    val totalTasksCompleted: Int = 12,
    val totalDeepWorkMinutes: Int = 180,
    val currentStreakDays: Int = 5,
    val unlockedBadgesCsv: String = "DEEP_WORK_TITAN,STREAK_5_DAYS,NAVAL_PIONEER",
    val completedChallengeIdsCsv: String = "CHALLENGE_1"
)
