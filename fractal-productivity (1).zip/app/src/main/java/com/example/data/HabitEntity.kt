package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val targetDaysPerWeek: Int = 7,
    val currentStreak: Int = 0,
    val bestStreak: Int = 0,
    val colorHex: String = "#6366F1",
    val iconName: String = "CheckCircle",
    val completedDatesCsv: String = "", // e.g. "2026-08-10,2026-08-11,2026-08-12"
    val createdAt: Long = System.currentTimeMillis()
)
