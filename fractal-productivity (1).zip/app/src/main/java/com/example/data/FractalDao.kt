package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface FractalDao {
    // Tasks
    @Query("SELECT * FROM tasks ORDER BY scheduledDate ASC, startTime ASC")
    fun getAllTasks(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE scheduledDate = :date ORDER BY startTime ASC")
    fun getTasksForDate(date: String): Flow<List<TaskEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: TaskEntity): Long

    @Update
    suspend fun updateTask(task: TaskEntity)

    @Delete
    suspend fun deleteTask(task: TaskEntity)

    @Query("SELECT COUNT(*) FROM tasks")
    suspend fun getTaskCount(): Int

    // Habits
    @Query("SELECT * FROM habits ORDER BY id ASC")
    fun getAllHabits(): Flow<List<HabitEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertHabit(habit: HabitEntity): Long

    @Update
    suspend fun updateHabit(habit: HabitEntity)

    @Delete
    suspend fun deleteHabit(habit: HabitEntity)

    @Query("SELECT COUNT(*) FROM habits")
    suspend fun getHabitCount(): Int

    // Naval Projects
    @Query("SELECT * FROM naval_projects ORDER BY id DESC")
    fun getAllNavalProjects(): Flow<List<NavalProjectEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNavalProject(project: NavalProjectEntity): Long

    @Update
    suspend fun updateNavalProject(project: NavalProjectEntity)

    @Delete
    suspend fun deleteNavalProject(project: NavalProjectEntity)

    @Query("SELECT COUNT(*) FROM naval_projects")
    suspend fun getNavalProjectCount(): Int

    // Gamification
    @Query("SELECT * FROM user_gamification WHERE id = 1")
    fun getUserGamification(): Flow<UserGamificationEntity?>

    @Query("SELECT * FROM user_gamification WHERE id = 1")
    suspend fun getUserGamificationDirect(): UserGamificationEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateGamification(gamification: UserGamificationEntity)
}
