package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalContext

private val DarkColorScheme = darkColorScheme(
    primary = FractalPrimaryDark,
    onPrimary = FractalOnPrimaryDark,
    secondary = FractalSecondaryDark,
    tertiary = FractalTertiaryDark,
    background = FractalBackgroundDark,
    surface = FractalSurfaceDark,
    surfaceVariant = FractalSurfaceVariantDark
)

private val LightColorScheme = lightColorScheme(
    primary = FractalPrimaryLight,
    onPrimary = FractalOnPrimaryLight,
    secondary = FractalSecondaryLight,
    tertiary = FractalTertiaryLight,
    background = FractalBackgroundLight,
    surface = FractalSurfaceLight,
    surfaceVariant = FractalSurfaceVariantLight
)

@Composable
fun FractalTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    dynamicColor: Boolean = false, // Set false to ensure our custom branded palette renders consistently
    content: @Composable () -> Unit
) {
    val colorScheme = when {
        dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
            val context = LocalContext.current
            if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
        }
        darkTheme -> DarkColorScheme
        else -> LightColorScheme
    }

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
