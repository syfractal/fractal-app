package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.LeverageType
import com.example.ui.theme.AccentNavalGold

@Composable
fun AddNavalProjectDialog(
    onDismiss: () -> Unit,
    onConfirm: (
        title: String,
        specificKnowledge: String,
        leverageType: LeverageType,
        productizationIdea: String,
        monetizationStrategy: String,
        automationSteps: String,
        targetImpact: String
    ) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var specificKnowledge by remember { mutableStateOf("") }
    var leverageType by remember { mutableStateOf(LeverageType.CODE) }
    var productizationIdea by remember { mutableStateOf("") }
    var monetizationStrategy by remember { mutableStateOf("") }
    var automationSteps by remember { mutableStateOf("") }
    var targetImpact by remember { mutableStateOf("$10,000 / mo MRR") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(
                    text = "🏆 Naval Leverage Project Builder",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "Productize yourself. Use code, media, or capital leverage.",
                    style = MaterialTheme.typography.labelSmall,
                    color = AccentNavalGold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Project Title") },
                    placeholder = { Text("e.g. Automated SaaS Engine / AI Newsletter") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("add_naval_title_input"),
                    singleLine = true
                )

                OutlinedTextField(
                    value = specificKnowledge,
                    onValueChange = { specificKnowledge = it },
                    label = { Text("1. Specific Knowledge (Your Unfair Advantage)") },
                    placeholder = { Text("What comes naturally to you that feels like play to you, but work to others?") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                // Leverage Type Chips
                Text(
                    text = "2. Primary Leverage Type:",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    LeverageType.entries.forEach { lev ->
                        FilterChip(
                            selected = leverageType == lev,
                            onClick = { leverageType = lev },
                            label = { Text(lev.name.replace("_", " "), fontSize = 10.sp) }
                        )
                    }
                }

                OutlinedTextField(
                    value = productizationIdea,
                    onValueChange = { productizationIdea = it },
                    label = { Text("3. Productization of Self") },
                    placeholder = { Text("How do you turn your skill into code or digital media assets?") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                OutlinedTextField(
                    value = monetizationStrategy,
                    onValueChange = { monetizationStrategy = it },
                    label = { Text("4. Monetization Strategy") },
                    placeholder = { Text("Subscription, software licenses, media ads, course sales") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                OutlinedTextField(
                    value = automationSteps,
                    onValueChange = { automationSteps = it },
                    label = { Text("5. Automation & Systemization Plan") },
                    placeholder = { Text("Serverless cloud, Stripe integration, auto content delivery") },
                    modifier = Modifier.fillMaxWidth(),
                    maxLines = 2
                )

                OutlinedTextField(
                    value = targetImpact,
                    onValueChange = { targetImpact = it },
                    label = { Text("6. Target Monetization Milestone") },
                    placeholder = { Text("e.g. $10k/mo MRR or 50k Active Users") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onConfirm(
                            title,
                            specificKnowledge,
                            leverageType,
                            productizationIdea,
                            monetizationStrategy,
                            automationSteps,
                            targetImpact
                        )
                    }
                },
                modifier = Modifier.testTag("confirm_add_naval_button")
            ) {
                Text("Launch Leverage Goal")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
