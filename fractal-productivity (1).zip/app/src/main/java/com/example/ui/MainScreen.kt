package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AddHabitDialog
import com.example.ui.components.AddNavalProjectDialog
import com.example.ui.components.AddTaskDialog
import com.example.ui.screens.AnalyticsHabitsScreen
import com.example.ui.screens.ChallengerScreen
import com.example.ui.screens.NavalModeScreen
import com.example.ui.screens.PlannerScreen
import com.example.ui.theme.AccentAmber
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.FractalPrimaryDark
import com.example.ui.theme.FractalTertiaryDark

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val selectedTab by viewModel.selectedTab.collectAsState()
    val gamification by viewModel.userGamification.collectAsState()

    val showAddTaskDialog by viewModel.showAddTaskDialog.collectAsState()
    val showAddHabitDialog by viewModel.showAddHabitDialog.collectAsState()
    val showAddNavalProjectDialog by viewModel.showAddNavalProjectDialog.collectAsState()
    val selectedDate by viewModel.selectedDate.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                        modifier = Modifier.fillMaxWidth().padding(end = 8.dp)
                    ) {
                        Column {
                            Text(
                                text = "Fractal Productivity",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Code Exported by Antigravity",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Icon(
                                    imageVector = Icons.Default.FolderZip,
                                    contentDescription = "Export ZIP",
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(12.dp)
                                )
                            }
                        }

                        // Top Bar Badges: Lvl & Streak
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Streak pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(AccentAmber.copy(alpha = 0.15f))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.LocalFireDepartment,
                                        contentDescription = "Streak",
                                        tint = AccentAmber,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "${gamification?.currentStreakDays ?: 5}d",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = AccentAmber
                                    )
                                }
                            }

                            // Level pill
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(Brush.horizontalGradient(listOf(FractalPrimaryDark, FractalTertiaryDark)))
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Default.Star,
                                        contentDescription = "Level",
                                        tint = Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(3.dp))
                                    Text(
                                        text = "Lvl ${gamification?.userLevel ?: 2}",
                                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier
                    .windowInsetsPadding(WindowInsets.navigationBars)
                    .testTag("bottom_navigation_bar")
            ) {
                NavigationBarItem(
                    selected = selectedTab == 0,
                    onClick = { viewModel.selectTab(0) },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == 0) Icons.Default.CalendarToday else Icons.Outlined.CalendarToday,
                            contentDescription = "Day Planner"
                        )
                    },
                    label = { Text("Day Planner", fontSize = 10.sp) },
                    modifier = Modifier.testTag("tab_planner")
                )

                NavigationBarItem(
                    selected = selectedTab == 1,
                    onClick = { viewModel.selectTab(1) },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == 1) Icons.Default.BarChart else Icons.Outlined.BarChart,
                            contentDescription = "Analytics & Habits"
                        )
                    },
                    label = { Text("Analytics & Habits", fontSize = 10.sp) },
                    modifier = Modifier.testTag("tab_analytics")
                )

                NavigationBarItem(
                    selected = selectedTab == 2,
                    onClick = { viewModel.selectTab(2) },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == 2) Icons.Default.EmojiEvents else Icons.Outlined.EmojiEvents,
                            contentDescription = "Challenger"
                        )
                    },
                    label = { Text("Challenger", fontSize = 10.sp) },
                    modifier = Modifier.testTag("tab_challenger")
                )

                NavigationBarItem(
                    selected = selectedTab == 3,
                    onClick = { viewModel.selectTab(3) },
                    icon = {
                        Icon(
                            imageVector = if (selectedTab == 3) Icons.Default.RocketLaunch else Icons.Outlined.RocketLaunch,
                            contentDescription = "Naval Mode"
                        )
                    },
                    label = { Text("Naval Mode", fontSize = 10.sp) },
                    modifier = Modifier.testTag("tab_naval")
                )
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
        ) {
            when (selectedTab) {
                0 -> PlannerScreen(viewModel = viewModel)
                1 -> AnalyticsHabitsScreen(viewModel = viewModel)
                2 -> ChallengerScreen(viewModel = viewModel)
                3 -> NavalModeScreen(viewModel = viewModel)
            }
        }

        // Dialogs
        if (showAddTaskDialog) {
            AddTaskDialog(
                scheduledDate = selectedDate,
                onDismiss = { viewModel.openAddTaskDialog(false) },
                onConfirm = { title, desc, cat, prio, date, start, end, isDeep, rec, rem ->
                    viewModel.addNewTask(title, desc, cat, prio, date, start, end, isDeep, rec, rem, null)
                }
            )
        }

        if (showAddHabitDialog) {
            AddHabitDialog(
                onDismiss = { viewModel.openAddHabitDialog(false) },
                onConfirm = { title, desc, targetDays, colorHex ->
                    viewModel.addNewHabit(title, desc, targetDays, colorHex)
                }
            )
        }

        if (showAddNavalProjectDialog) {
            AddNavalProjectDialog(
                onDismiss = { viewModel.openAddNavalProjectDialog(false) },
                onConfirm = { title, knowledge, levType, idea, mon, auto, impact ->
                    viewModel.addNewNavalProject(title, knowledge, levType, idea, mon, auto, impact)
                }
            )
        }
    }
}
