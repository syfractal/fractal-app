package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Palette
val FractalPrimaryLight = Color(0xFF4F46E5) // Indigo
val FractalOnPrimaryLight = Color(0xFFFFFFFF)
val FractalSecondaryLight = Color(0xFF0EA5E9) // Sky Blue
val FractalTertiaryLight = Color(0xFF8B5CF6) // Violet
val FractalBackgroundLight = Color(0xFFF8FAFC) // Slate 50
val FractalSurfaceLight = Color(0xFFFFFFFF)
val FractalSurfaceVariantLight = Color(0xFFF1F5F9)

// Dark Palette (Default Premium Vibe)
val FractalPrimaryDark = Color(0xFF818CF8) // Glowing Indigo
val FractalOnPrimaryDark = Color(0xFF0F172A)
val FractalSecondaryDark = Color(0xFF38BDF8) // Bright Cyan
val FractalTertiaryDark = Color(0xFFC084FC) // Glowing Violet
val FractalBackgroundDark = Color(0xFF090D16) // Deep Dark Obsidian
val FractalSurfaceDark = Color(0xFF131B2E) // Deep Navy Surface
val FractalSurfaceVariantDark = Color(0xFF1E293B) // Card Border/Surface

// Accents
val AccentEmerald = Color(0xFF10B981)
val AccentAmber = Color(0xFFF59E0B)
val AccentRose = Color(0xFFEF4444)
val AccentDeepWork = Color(0xFF6366F1)
val AccentNavalGold = Color(0xFFFBBF24)
