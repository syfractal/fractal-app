package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.Priority
import com.example.data.TaskCategory
import com.example.data.TaskEntity
import com.example.ui.MainViewModel
import com.example.ui.components.TaskItemCard
import com.example.ui.components.TimeBlockCard
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.AccentRose
import com.example.ui.theme.FractalPrimaryDark
import com.example.ui.theme.FractalTertiaryDark

@Composable
fun PlannerScreen(
    viewModel: MainViewModel,
    modifier: Modifier = Modifier
) {
    val selectedDate by viewModel.selectedDate.collectAsState()
    val tasks by viewModel.tasksForSelectedDate.collectAsState()
    val priorityFilter by viewModel.priorityFilter.collectAsState()
    val categoryFilter by viewModel.categoryFilter.collectAsState()

    val calendarDays = remember { viewModel.getCalendarDays() }
    var isTimelineView by remember { mutableStateOf(false) }

    // Filter tasks
    val filteredTasks = tasks.filter { task ->
        (priorityFilter == null || task.priority == priorityFilter) &&
        (categoryFilter == null || task.category == categoryFilter)
    }

    val deepWorkTasks = filteredTasks.filter { it.isDeepWorkBlock }
    val deepWorkMins = deepWorkTasks.size * 60

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = { viewModel.openAddTaskDialog(true) },
                icon = { Icon(Icons.Default.Add, contentDescription = "Add Task") },
                text = { Text("Add Block / Task") },
                containerColor = FractalPrimaryDark,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_task_fab")
            )
        },
        modifier = modifier
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .padding(horizontal = 16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            // Calendar Horizontal Date Picker
            Text(
                text = "📅 Integrated Calendar Planner",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )

            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("calendar_date_picker")
            ) {
                items(calendarDays) { (dayLabel, dateStr) ->
                    val isSelected = dateStr == selectedDate
                    val isToday = dateStr == viewModel.todayString

                    Surface(
                        onClick = { viewModel.selectDate(dateStr) },
                        shape = RoundedCornerShape(14.dp),
                        color = if (isSelected) FractalPrimaryDark else if (isToday) MaterialTheme.colorScheme.surfaceVariant else MaterialTheme.colorScheme.surface,
                        border = if (isToday && !isSelected) BorderStroke(1.dp, FractalPrimaryDark) else null,
                        modifier = Modifier.width(54.dp)
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.Center,
                            modifier = Modifier.padding(vertical = 10.dp)
                        ) {
                            val parts = dayLabel.split("\n")
                            Text(
                                text = parts.getOrNull(0) ?: "",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = parts.getOrNull(1) ?: "",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = if (isSelected) Color.White else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Deep Work Summary Banner
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = CardDefaults.outlinedCardBorder().copy(
                    brush = Brush.horizontalGradient(listOf(FractalPrimaryDark, FractalTertiaryDark)),
                    width = 1.dp
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .padding(14.dp)
                        .fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Bolt,
                            contentDescription = null,
                            tint = FractalTertiaryDark,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Deep Work Focus Block",
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "$deepWorkMins mins scheduled today (${deepWorkTasks.count { it.isCompleted }}/${deepWorkTasks.size} completed)",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // View Switcher (List vs Timeline)
                    IconButton(
                        onClick = { isTimelineView = !isTimelineView },
                        modifier = Modifier.testTag("toggle_view_mode")
                    ) {
                        Icon(
                            imageVector = if (isTimelineView) Icons.Default.List else Icons.Default.ViewTimeline,
                            contentDescription = "Switch View",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Priority Filter Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Filter:",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Priority.entries.forEach { p ->
                    FilterChip(
                        selected = priorityFilter == p,
                        onClick = { viewModel.setPriorityFilter(p) },
                        label = { Text(p.name, fontSize = 10.sp) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Task List or Schedule Timeline
            if (filteredTasks.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.EventAvailable,
                            contentDescription = "No tasks",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.4f),
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No time blocks scheduled for this date.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "Tap + to add your first Deep Work block!",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            } else if (isTimelineView) {
                // Hour-by-hour Timeline view (08:00 to 20:00)
                val hours = (8..20).map { String.format("%02d:00", it) }

                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    items(hours) { hr ->
                        val tasksInHr = filteredTasks.filter {
                            it.startTime.startsWith(hr.take(2)) || it.endTime.startsWith(hr.take(2))
                        }
                        TimeBlockCard(
                            hourLabel = hr,
                            tasksInHour = tasksInHr,
                            onToggleTask = { viewModel.toggleTaskCompletion(it) }
                        )
                    }
                }
            } else {
                // Standard Task List View
                LazyColumn(
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(filteredTasks, key = { it.id }) { task ->
                        TaskItemCard(
                            task = task,
                            onToggleComplete = { viewModel.toggleTaskCompletion(task) },
                            onDelete = { viewModel.deleteTask(task) }
                        )
                    }
                }
            }
        }
    }
}
