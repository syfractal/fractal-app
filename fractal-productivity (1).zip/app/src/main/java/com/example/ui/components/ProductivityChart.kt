package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AccentEmerald
import com.example.ui.theme.FractalPrimaryDark
import com.example.ui.theme.FractalSecondaryDark
import com.example.ui.theme.FractalTertiaryDark

@Composable
fun WeeklyBarChart(
    days: List<String> = listOf("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"),
    deepWorkHours: List<Float> = listOf(2.5f, 3.0f, 4.5f, 1.5f, 3.5f, 2.0f, 4.0f),
    modifier: Modifier = Modifier
) {
    val maxVal = (deepWorkHours.maxOrNull() ?: 5.0f).coerceAtLeast(1.0f)
    val barColor = FractalPrimaryDark
    val secondaryBarColor = FractalTertiaryDark

    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Text(
                text = "⚡ Deep Work Hours (Weekly Block Report)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onSurface
            )
            Text(
                text = "Total Deep Hours: ${deepWorkHours.sum()} hrs • Daily Average: ${String.format("%.1f", deepWorkHours.average())} hrs",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(modifier = Modifier.height(18.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(140.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val width = size.width
                    val height = size.height
                    val barWidth = width / (days.size * 2)
                    val spacing = barWidth

                    days.forEachIndexed { index, _ ->
                        val value = deepWorkHours.getOrElse(index) { 0f }
                        val barHeight = (value / maxVal) * (height - 30.dp.toPx())
                        val x = index * (barWidth + spacing) + spacing / 2

                        // Draw background track
                        drawRoundRect(
                            color = Color.Gray.copy(alpha = 0.15f),
                            topLeft = Offset(x, 0f),
                            size = Size(barWidth, height - 30.dp.toPx()),
                            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                        )

                        // Draw active bar
                        drawRoundRect(
                            brush = Brush.verticalGradient(
                                listOf(secondaryBarColor, barColor)
                            ),
                            topLeft = Offset(x, height - 30.dp.toPx() - barHeight),
                            size = Size(barWidth, barHeight),
                            cornerRadius = CornerRadius(8.dp.toPx(), 8.dp.toPx())
                        )
                    }
                }

                // X-Axis Labels
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .align(Alignment.BottomCenter),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    days.forEach { day ->
                        Text(
                            text = day,
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun HabitConsistencyTrend(
    completionPercentages: List<Float> = listOf(60f, 75f, 80f, 85f, 90f, 95f, 100f),
    modifier: Modifier = Modifier
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder(),
        modifier = modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            Row(
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column {
                    Text(
                        text = "📈 Habit Consistency Velocity",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Text(
                        text = "7-Day Streak Momentum",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .background(AccentEmerald.copy(alpha = 0.15f))
                        .padding(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(
                        text = "92% Score",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                        color = AccentEmerald
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(110.dp)
            ) {
                Canvas(modifier = Modifier.fillMaxSize()) {
                    val w = size.width
                    val h = size.height
                    val stepX = w / (completionPercentages.size - 1)

                    val path = Path()
                    completionPercentages.forEachIndexed { idx, pct ->
                        val x = idx * stepX
                        val y = h - ((pct / 100f) * h)
                        if (idx == 0) path.moveTo(x, y) else path.lineTo(x, y)
                    }

                    // Line curve
                    drawPath(
                        path = path,
                        brush = Brush.horizontalGradient(listOf(FractalSecondaryDark, AccentEmerald)),
                        style = Stroke(width = 4.dp.toPx())
                    )

                    // Draw points
                    completionPercentages.forEachIndexed { idx, pct ->
                        val x = idx * stepX
                        val y = h - ((pct / 100f) * h)
                        drawCircle(
                            color = AccentEmerald,
                            radius = 5.dp.toPx(),
                            center = Offset(x, y)
                        )
                    }
                }
            }
        }
    }
}
