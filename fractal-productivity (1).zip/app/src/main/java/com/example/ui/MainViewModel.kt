package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val repository = FractalRepository(db.fractalDao())

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    val todayString: String = dateFormat.format(Date())

    private val _selectedTab = MutableStateFlow(0)
    val selectedTab: StateFlow<Int> = _selectedTab.asStateFlow()

    private val _selectedDate = MutableStateFlow(todayString)
    val selectedDate: StateFlow<String> = _selectedDate.asStateFlow()

    private val _priorityFilter = MutableStateFlow<Priority?>(null)
    val priorityFilter: StateFlow<Priority?> = _priorityFilter.asStateFlow()

    private val _categoryFilter = MutableStateFlow<TaskCategory?>(null)
    val categoryFilter: StateFlow<TaskCategory?> = _categoryFilter.asStateFlow()

    // Dialog flags
    private val _showAddTaskDialog = MutableStateFlow(false)
    val showAddTaskDialog: StateFlow<Boolean> = _showAddTaskDialog.asStateFlow()

    private val _showAddHabitDialog = MutableStateFlow(false)
    val showAddHabitDialog: StateFlow<Boolean> = _showAddHabitDialog.asStateFlow()

    private val _showAddNavalProjectDialog = MutableStateFlow(false)
    val showAddNavalProjectDialog: StateFlow<Boolean> = _showAddNavalProjectDialog.asStateFlow()

    // Reactive streams from Room
    val userGamification: StateFlow<UserGamificationEntity?> = repository.userGamification
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val allTasks: StateFlow<List<TaskEntity>> = repository.allTasks
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val tasksForSelectedDate: StateFlow<List<TaskEntity>> = _selectedDate
        .flatMapLatest { date -> repository.getTasksForDate(date) }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allHabits: StateFlow<List<HabitEntity>> = repository.allHabits
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allNavalProjects: StateFlow<List<NavalProjectEntity>> = repository.allNavalProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    init {
        viewModelScope.launch {
            repository.checkAndSeedInitialData()
        }
    }

    fun selectTab(index: Int) {
        _selectedTab.value = index
    }

    fun selectDate(dateStr: String) {
        _selectedDate.value = dateStr
    }

    fun setPriorityFilter(priority: Priority?) {
        _priorityFilter.value = if (_priorityFilter.value == priority) null else priority
    }

    fun setCategoryFilter(category: TaskCategory?) {
        _categoryFilter.value = if (_categoryFilter.value == category) null else category
    }

    fun openAddTaskDialog(show: Boolean) {
        _showAddTaskDialog.value = show
    }

    fun openAddHabitDialog(show: Boolean) {
        _showAddHabitDialog.value = show
    }

    fun openAddNavalProjectDialog(show: Boolean) {
        _showAddNavalProjectDialog.value = show
    }

    fun toggleTaskCompletion(task: TaskEntity) {
        viewModelScope.launch {
            val newCompletedState = !task.isCompleted
            val updated = task.copy(isCompleted = newCompletedState)
            repository.updateTask(updated)

            if (newCompletedState) {
                val deepMins = if (task.isDeepWorkBlock) 60 else 0
                repository.addXpAndProgress(task.xpReward, deepMins)
            }
        }
    }

    fun addNewTask(
        title: String,
        description: String,
        category: TaskCategory,
        priority: Priority,
        scheduledDate: String,
        startTime: String,
        endTime: String,
        isDeepWorkBlock: Boolean,
        recurrence: Recurrence,
        reminderTime: String?,
        navalProjectId: Long?
    ) {
        viewModelScope.launch {
            val xp = when {
                isDeepWorkBlock -> 60
                category == TaskCategory.NAVAL_GOAL -> 50
                priority == Priority.URGENT -> 40
                else -> 25
            }
            val newTask = TaskEntity(
                title = title,
                description = description,
                category = category,
                priority = priority,
                scheduledDate = scheduledDate,
                startTime = startTime,
                endTime = endTime,
                isDeepWorkBlock = isDeepWorkBlock,
                recurrence = recurrence,
                reminderTime = reminderTime,
                navalProjectId = navalProjectId,
                xpReward = xp
            )
            repository.insertTask(newTask)
            _showAddTaskDialog.value = false
        }
    }

    fun deleteTask(task: TaskEntity) {
        viewModelScope.launch {
            repository.deleteTask(task)
        }
    }

    fun toggleHabitForDate(habit: HabitEntity, dateStr: String) {
        viewModelScope.launch {
            val dateList = habit.completedDatesCsv.split(",").filter { it.isNotBlank() }.toMutableList()
            val isCompleted = dateList.contains(dateStr)

            if (isCompleted) {
                dateList.remove(dateStr)
            } else {
                dateList.add(dateStr)
                repository.addXpAndProgress(20)
            }

            val newStreak = if (!isCompleted) habit.currentStreak + 1 else maxOf(0, habit.currentStreak - 1)
            val newBest = maxOf(habit.bestStreak, newStreak)

            val updated = habit.copy(
                completedDatesCsv = dateList.joinToString(","),
                currentStreak = newStreak,
                bestStreak = newBest
            )
            repository.updateHabit(updated)
        }
    }

    fun addNewHabit(title: String, description: String, targetDays: Int, colorHex: String) {
        viewModelScope.launch {
            val newHabit = HabitEntity(
                title = title,
                description = description,
                targetDaysPerWeek = targetDays,
                colorHex = colorHex
            )
            repository.insertHabit(newHabit)
            _showAddHabitDialog.value = false
        }
    }

    fun deleteHabit(habit: HabitEntity) {
        viewModelScope.launch {
            repository.deleteHabit(habit)
        }
    }

    fun addNewNavalProject(
        title: String,
        specificKnowledge: String,
        leverageType: LeverageType,
        productizationIdea: String,
        monetizationStrategy: String,
        automationSteps: String,
        targetImpact: String
    ) {
        viewModelScope.launch {
            val project = NavalProjectEntity(
                title = title,
                specificKnowledge = specificKnowledge,
                leverageType = leverageType,
                productizationIdea = productizationIdea,
                monetizationStrategy = monetizationStrategy,
                automationSteps = automationSteps,
                progressPercent = 15,
                targetImpactOrRevenue = targetImpact,
                status = "In Development"
            )
            val insertedId = repository.insertNavalProject(project)

            // Also create an associated time-blocked deep work task in calendar for Naval execution
            repository.insertTask(
                TaskEntity(
                    title = "Naval Execution: $title",
                    description = "Focus block to build $productizationIdea using $leverageType leverage",
                    category = TaskCategory.NAVAL_GOAL,
                    priority = Priority.HIGH,
                    scheduledDate = todayString,
                    startTime = "15:00",
                    endTime = "16:30",
                    isDeepWorkBlock = true,
                    navalProjectId = insertedId,
                    xpReward = 50
                )
            )

            repository.addXpAndProgress(75) // Bonus XP for launching a Naval leverage project!
            _showAddNavalProjectDialog.value = false
        }
    }

    fun updateNavalProjectProgress(project: NavalProjectEntity, newProgress: Int) {
        viewModelScope.launch {
            val status = when {
                newProgress >= 100 -> "Monetized & Scaled"
                newProgress >= 60 -> "Public Beta / Launching"
                newProgress >= 30 -> "In Active Build"
                else -> "Planning"
            }
            val updated = project.copy(
                progressPercent = newProgress.coerceIn(0, 100),
                status = status
            )
            repository.updateNavalProject(updated)
            if (newProgress >= 100) {
                repository.addXpAndProgress(200) // Huge XP reward for monetizing!
            }
        }
    }

    fun deleteNavalProject(project: NavalProjectEntity) {
        viewModelScope.launch {
            repository.deleteNavalProject(project)
        }
    }

    // Helper date generator for calendar horizontal picker
    fun getCalendarDays(): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>() // Pair(DayName, DateYYYYMMDD)
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, -3)

        val dayFormat = SimpleDateFormat("EEE", Locale.getDefault())
        val numFormat = SimpleDateFormat("dd", Locale.getDefault())

        for (i in 0..13) {
            val fullDateStr = dateFormat.format(cal.time)
            val displayLabel = "${dayFormat.format(cal.time)}\n${numFormat.format(cal.time)}"
            result.add(Pair(displayLabel, fullDateStr))
            cal.add(Calendar.DAY_OF_YEAR, 1)
        }
        return result
    }
}
